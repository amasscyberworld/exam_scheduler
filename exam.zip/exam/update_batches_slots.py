# This script updates all relevant display labels and slot references
# to use "Batch" terminology instead of "Slot".

import sqlite3

# Connect to the existing database
conn = sqlite3.connect("scheduler.db")
cursor = conn.cursor()

# Rename existing column or adjust references in the application if needed
# In most cases, we only change frontend labels, not actual column names

# Fetch all unique slot numbers to convert them to batches
cursor.execute("SELECT DISTINCT slot FROM students WHERE slot IS NOT NULL")
slots = cursor.fetchall()

batch_map = {
    1: 'A',
    2: 'B',
    3: 'C',
    4: 'D',
    5: 'E'
}

# Generate batch labels in slot_times table
slot_updates = [
    (1, '08:00AM', '10:00AM'),
    (2, '10:00AM', '12:00PM'),
    (3, '12:00PM', '02:00PM'),
    (4, '02:00PM', '04:00PM'),
    (5, '04:00PM', '06:00PM')
]

cursor.execute("DELETE FROM slot_times")

for slot, start, end in slot_updates:
    cursor.execute("INSERT INTO slot_times (slot, start_time, end_time) VALUES (?, ?, ?)", (slot, start, end))

conn.commit()
print("Slot times updated to reflect Batch schedule (A to E).")

# Output mapping for integration reference
print("Batch Mapping:")
for s in slots:
    slot_num = s[0]
    batch = batch_map.get(slot_num, f"{slot_num}")
    print(f"Slot {slot_num} -> Batch {batch}")

conn.close()
