EMAIL_ADDRESS = 'amasscyberworld@gmail.com'
EMAIL_PASSWORD = 'Hamdancyberlord@X'
