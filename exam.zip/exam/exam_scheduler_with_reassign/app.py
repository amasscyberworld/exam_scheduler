
from flask import Flask, render_template, request, redirect, url_for, session, Response
import sqlite3
from slot_allocator import assign_slots

app = Flask(__name__)
app.secret_key = 'secure_exam_key'

def get_db():
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    return conn

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    matric = request.form['matric']
    dept = request.form['department']
    level = request.form['level']
    db = get_db()
    cursor = db.cursor()
    cursor.execute("INSERT OR IGNORE INTO students (matric, department, level) VALUES (?, ?, ?)",
                   (matric, dept, level))
    db.commit()
    cursor.execute("SELECT slot FROM students WHERE matric = ?", (matric,))
    result = cursor.fetchone()
    slot = result['slot'] if result else None
    if slot:
        cursor.execute("SELECT start_time, end_time FROM slot_times WHERE slot = ?", (slot,))
        time = cursor.fetchone()
        start_time = time['start_time'] if time else "N/A"
        end_time = time['end_time'] if time else "N/A"
    else:
        start_time = end_time = "Not assigned"
    session['matric'] = matric
    session['slot'] = slot
    session['start'] = start_time
    session['end'] = end_time
    return redirect(url_for('student_slot'))

@app.route('/student_slot')
def student_slot():
    if 'matric' not in session:
        return redirect(url_for('index'))
    return render_template('student_slot.html', slot=session['slot'], start=session['start'], end=session['end'], matric=session['matric'])

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin123':
            session['admin_logged_in'] = True
            return redirect(url_for('admin'))
        else:
            return "Invalid credentials"
    return render_template('admin_login.html')

@app.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('admin_login'))

@app.before_request
def require_login():
    protected_routes = ['/admin', '/upload', '/export', '/reassign']
    exempt_routes = ['/admin_login', '/logout', '/static', '/']
    if any(request.path.startswith(route) for route in protected_routes):
        if request.path not in exempt_routes and 'admin_logged_in' not in session:
            return redirect(url_for('admin_login'))


@app.route('/admin')
def admin():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM students")
    students = cursor.fetchall()

    cursor.execute("SELECT slot, COUNT(*) as count FROM students GROUP BY slot ORDER BY slot ASC")
    stats = cursor.fetchall()
    slot_labels = [str(row['slot']) for row in stats]
    slot_counts = [row['count'] for row in stats]

    return render_template('admin.html', students=students, slot_labels=slot_labels, slot_counts=slot_counts)


@app.route('/reassign', methods=['POST'])
def reassign():
    matric = request.form['matric']
    new_slot = request.form['new_slot']
    db = get_db()
    cursor = db.cursor()
    cursor.execute("UPDATE students SET slot = ? WHERE matric = ?", (new_slot, matric))
    db.commit()
    return redirect(url_for('admin'))

@app.route('/upload', methods=['POST'])
def upload():
    import csv
    from io import TextIOWrapper
    file = request.files['file']
    stream = TextIOWrapper(file.stream)
    reader = csv.DictReader(stream)
    students = []
    db = get_db()
    cursor = db.cursor()
    for row in reader:
        matric = row['matric']
        department = row['department']
        level = row['level']
        cursor.execute("SELECT slot FROM students WHERE matric = ?", (matric,))
        existing = cursor.fetchone()
        if not existing or not existing['slot']:
            students.append({'matric': matric, 'department': department, 'level': level})
    cursor.execute("SELECT MAX(CAST(slot AS INTEGER)) as max_slot FROM students")
    result = cursor.fetchone()
    last_slot = result['max_slot'] if result['max_slot'] else 0
    start_slot = last_slot + 1
    grouped = assign_slots(students, start_slot=start_slot)
    for slot, group in grouped.items():
        for s in group:
            cursor.execute("INSERT OR REPLACE INTO students (matric, department, level, slot) VALUES (?, ?, ?, ?)",
                           (s['matric'], s['department'], s['level'], str(slot)))
    db.commit()
    return redirect(url_for('admin'))

@app.route('/export')
def export():
    import csv
    from io import StringIO
    db = get_db()
    cursor = db.cursor()
    cursor.execute('''
        SELECT s.matric, s.department, s.level, s.slot, t.start_time, t.end_time
        FROM students s
        LEFT JOIN slot_times t ON s.slot = t.slot
        ORDER BY s.slot ASC
    ''')
    rows = cursor.fetchall()
    output = StringIO()
    writer = csv.writer(output)
    writer.writerow(['Matric', 'Department', 'Level', 'Slot', 'Start Time', 'End Time'])
    for row in rows:
        writer.writerow([row['matric'], row['department'], row['level'],
                         row['slot'], row['start_time'], row['end_time']])
    output.seek(0)
    return Response(output, mimetype='text/csv',
                    headers={"Content-Disposition": "attachment;filename=exam_schedule.csv"})

if __name__ == '__main__':
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS students (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        matric TEXT UNIQUE,
                        department TEXT,
                        level TEXT,
                        slot TEXT)''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS slot_times (
            slot INTEGER PRIMARY KEY,
            start_time TEXT,
            end_time TEXT
        )
    ''')
    for i in range(10):
        start_hour = 9 + i
        cursor.execute("INSERT OR IGNORE INTO slot_times (slot, start_time, end_time) VALUES (?, ?, ?)",
                       (i+1, f"{start_hour:02}:00", f"{start_hour+1:02}:00"))
    conn.commit()
    conn.close()
    app.run(debug=True)
